<!DOCTYPE html>
<html>
    <head>
        <title>Welcome to MadrasThemes</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="author" content="MadrasThemes Demos" />
        <meta name="description" content="MadrasThemes Demos - Home to demos of all our WooCommerce themes" />
        <meta name="keywords" content="Maintenance Mode" />
        <meta name="robots" content="index, follow" />
						<link rel="stylesheet" href="https://demo2.chethemes.com/wp-content/plugins/WP-Maintenance-Mode/assets/css/style.min.css">
				    </head>
    <body class="">
		
        <div class="wrap">
			<h1>MadrasThemes Demos</h1>			<h2><ul>
<li><a href="https://transvelo.github.io/electro/" target="_blank" rel="noopener">Electro - Electronics Store WooCommerce Theme</a></li>
<li><a href="https://transvelo.github.io/techmarket/" target="_blank" rel="noopener">Techmarket - Multi-demo &amp; Electronics Store WooCommerce Theme</a></li>
<li><a href="https://transvelo.github.io/pizzaro/" target="_blank" rel="noopener">Pizzaro - Fast Food &amp; Restaurant WooCommerce Theme</a></li>
</ul></h2>
			
			
						
			    
        </div>

        <script type='text/javascript'>
			var wpmm_vars = {"ajax_url": "https://demo2.chethemes.com/wp-admin/admin-ajax.php"};
        </script>
						<script src="https://demo2.chethemes.com/wp-includes/js/jquery/jquery.js"></script>
								<script src="https://demo2.chethemes.com/wp-content/plugins/WP-Maintenance-Mode/assets/js/scripts.min.js"></script>
				    </body>
</html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/


Served from: demo2.chethemes.com @ 2022-11-03 09:17:42 by W3 Total Cache
-->